
export interface GestureState {
  isOpenPalm: boolean;   // 张开手掌：放大/生长
  isPinching: boolean;   // 捏合：聚焦/能量凝聚
  isVictory: boolean;    // 胜利手势：切换颜色
  handX: number;
  handY: number;
}

export enum TreeColorMode {
  GOLD = 'GOLD',
  EMERALD = 'EMERALD',
  CANDY = 'CANDY',
  ICY = 'ICY',
  RAINBOW = 'RAINBOW',
  VIOLET = 'VIOLET',
  SUNSET = 'SUNSET'
}

export const COLOR_PALETTES = {
  [TreeColorMode.GOLD]: [0xffd700, 0xffa500, 0xff8c00, 0xffffff],
  [TreeColorMode.EMERALD]: [0x00ff7f, 0x006400, 0xadff2f, 0x228b22],
  [TreeColorMode.CANDY]: [0xff1493, 0xffffff, 0xff0000, 0xffc0cb],
  [TreeColorMode.ICY]: [0x00ffff, 0xf0f8ff, 0x1e90ff, 0xadd8e6],
  [TreeColorMode.RAINBOW]: [0xff0000, 0xff7f00, 0xffff00, 0x00ff00, 0x0000ff, 0x4b0082, 0x8b00ff],
  [TreeColorMode.VIOLET]: [0x9400d3, 0x4b0082, 0xee82ee, 0xff00ff],
  [TreeColorMode.SUNSET]: [0xff4500, 0xff8c00, 0xffd700, 0xb22222]
};
