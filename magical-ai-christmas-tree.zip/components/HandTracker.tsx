
import React, { useEffect, useRef } from 'react';
import { GestureState } from '../types';

interface HandTrackerProps {
  onStateChange: (state: GestureState) => void;
  onActive: (active: boolean) => void;
}

const HandTracker: React.FC<HandTrackerProps> = ({ onStateChange, onActive }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const isVictoryActive = useRef(false);

  useEffect(() => {
    if (!videoRef.current || !canvasRef.current) return;

    const videoElement = videoRef.current;
    const canvasElement = canvasRef.current;
    const canvasCtx = canvasElement.getContext('2d')!;

    // @ts-ignore
    const hands = new window.Hands({
      locateFile: (file: string) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`,
    });

    hands.setOptions({
      maxNumHands: 1,
      modelComplexity: 1,
      minDetectionConfidence: 0.7,
      minTrackingConfidence: 0.7,
    });

    hands.onResults((results: any) => {
      canvasCtx.save();
      canvasCtx.clearRect(0, 0, canvasElement.width, canvasElement.height);
      
      if (results.multiHandLandmarks && results.multiHandLandmarks.length > 0) {
        onActive(true);
        const landmarks = results.multiHandLandmarks[0];

        // @ts-ignore
        window.drawConnectors(canvasCtx, landmarks, window.HAND_CONNECTIONS, { color: '#ffffff55', lineWidth: 2 });
        // @ts-ignore
        window.drawLandmarks(canvasCtx, landmarks, { color: '#ffffff', lineWidth: 1, radius: 2 });

        // --- 逻辑判断 ---
        
        // 1. 捏合判断 (Pinch)
        const thumbTip = landmarks[4];
        const indexTip = landmarks[8];
        const pinchDist = Math.sqrt(Math.pow(thumbTip.x - indexTip.x, 2) + Math.pow(thumbTip.y - indexTip.y, 2));
        const isPinching = pinchDist < 0.04;

        // 2. 胜利手势判断 (Victory: 食指中指伸出，无名指小指收起)
        const indexUp = landmarks[8].y < landmarks[6].y;
        const middleUp = landmarks[12].y < landmarks[10].y;
        const ringDown = landmarks[16].y > landmarks[14].y;
        const pinkyDown = landmarks[20].y > landmarks[18].y;
        const isVictory = indexUp && middleUp && ringDown && pinkyDown;

        // 3. 手掌张开判断 (Open Palm: 所有手指尖都在关节上方)
        const allUp = [8, 12, 16, 20].every(idx => landmarks[idx].y < landmarks[idx - 2].y);
        const isOpenPalm = allUp && !isVictory;

        onStateChange({
          isOpenPalm,
          isPinching,
          isVictory,
          handX: landmarks[0].x,
          handY: landmarks[0].y
        });
      } else {
        onActive(false);
      }
      canvasCtx.restore();
    });

    // @ts-ignore
    const camera = new window.Camera(videoElement, {
      onFrame: async () => { await hands.send({ image: videoElement }); },
      width: 640,
      height: 480,
    });

    camera.start();
    return () => { camera.stop(); hands.close(); };
  }, []);

  return (
    <div className="relative w-full h-full bg-black">
      <video ref={videoRef} className="hidden" playsInline muted />
      <canvas ref={canvasRef} className="w-full h-full object-cover scale-x-[-1]" width={640} height={480} />
    </div>
  );
};

export default HandTracker;
