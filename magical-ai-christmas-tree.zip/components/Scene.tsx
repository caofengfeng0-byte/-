
import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { TreeColorMode, COLOR_PALETTES, GestureState } from '../types';

interface SceneProps {
  colorMode: TreeColorMode;
  gestureState: GestureState;
}

const Scene: React.FC<SceneProps> = ({ colorMode, gestureState }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<{
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    renderer: THREE.WebGLRenderer;
    treePoints: THREE.Points;
    snowPoints: THREE.Points;
    star: THREE.Group;
    originalPositions: Float32Array;
    particleCount: number;
    clock: THREE.Clock;
  } | null>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    const width = window.innerWidth;
    const height = window.innerHeight;
    const clock = new THREE.Clock();
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x000000, 0.012);

    const camera = new THREE.PerspectiveCamera(60, width / height, 0.1, 1000);
    camera.position.set(0, 5, 20);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    containerRef.current.appendChild(renderer.domElement);

    // --- 圣诞树几何建模 (体积化 + 6层) ---
    const particleCount = 45000; 
    const geometry = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    const originalPositions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);

    const generateTree = () => {
      let pIdx = 0;
      
      // 1. 树干 (Trunk) - 柱状立体感
      const trunkCount = Math.floor(particleCount * 0.08);
      for(let i=0; i<trunkCount; i++) {
        const h = Math.random() * 4;
        const r = 0.5 * Math.sqrt(Math.random()); // 内部填充
        const angle = Math.random() * Math.PI * 2;
        positions[pIdx] = Math.cos(angle) * r;
        positions[pIdx+1] = h - 9.5;
        positions[pIdx+2] = Math.sin(angle) * r;
        pIdx += 3;
      }

      // 2. 六层立体树冠 (Layers)
      const layerCount = 6;
      const particlesPerLayer = Math.floor((particleCount - pIdx/3) / layerCount);
      
      for(let l=0; l<layerCount; l++) {
        const layerHeight = 4.2;
        const yOffset = -5.5 + l * 2.8; // 缩小层间距，增加重叠立体感
        const maxRadius = 7.5 - l * 1.1;

        for(let i=0; i<particlesPerLayer; i++) {
          const hProgress = Math.random(); 
          const h = hProgress * layerHeight;
          const angle = Math.random() * Math.PI * 2;
          
          // 裙边算法：引入正弦波让边缘凹凸有致，模拟分叉
          const branchWave = Math.sin(angle * 8) * 0.15;
          const radiusAtH = (1 - hProgress) * maxRadius * (1 + branchWave);
          
          // 体积填充：不只是在表面(r=radiusAtH)，而是0到radiusAtH之间的分布
          // 使用 Math.sqrt(Math.random()) 确保粒子更多分布在边缘
          const r = radiusAtH * Math.sqrt(Math.random());

          // 随机扰动，打破机械感
          const jitter = 0.05;
          positions[pIdx] = Math.cos(angle) * r + (Math.random()-0.5)*jitter;
          positions[pIdx+1] = h + yOffset + (Math.random()-0.5)*jitter;
          positions[pIdx+2] = Math.sin(angle) * r + (Math.random()-0.5)*jitter;
          pIdx += 3;
        }
      }

      // 填充剩余空位
      while(pIdx < particleCount * 3) {
        positions[pIdx] = 0; positions[pIdx+1] = -100; positions[pIdx+2] = 0;
        pIdx += 3;
      }

      originalPositions.set(positions);
    };

    generateTree();

    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const treeMaterial = new THREE.PointsMaterial({
      size: 0.065,
      vertexColors: true,
      transparent: true,
      opacity: 0.9,
      blending: THREE.AdditiveBlending,
      sizeAttenuation: true
    });

    const treePoints = new THREE.Points(geometry, treeMaterial);
    scene.add(treePoints);

    // --- 真实 3D 五角星顶端 (Extrude Star) ---
    const starGroup = new THREE.Group();
    
    const starShape = new THREE.Shape();
    const starPoints = 5;
    const outerRadius = 0.8;
    const innerRadius = 0.35;
    for (let i = 0; i < starPoints * 2; i++) {
      const r = i % 2 === 0 ? outerRadius : innerRadius;
      const a = (i / (starPoints * 2)) * Math.PI * 2 - Math.PI / 2;
      const x = Math.cos(a) * r;
      const y = Math.sin(a) * r;
      if (i === 0) starShape.moveTo(x, y);
      else starShape.lineTo(x, y);
    }
    starShape.closePath();

    const starExtrudeSettings = {
      depth: 0.2,
      bevelEnabled: true,
      bevelThickness: 0.1,
      bevelSize: 0.1,
      bevelSegments: 3
    };

    const starGeom = new THREE.ExtrudeGeometry(starShape, starExtrudeSettings);
    starGeom.center(); // 居中
    const starMat = new THREE.MeshPhongMaterial({ 
      color: 0xfff000, 
      emissive: 0xffaa00,
      shininess: 100,
      specular: 0xffffff
    });
    const starMesh = new THREE.Mesh(starGeom, starMat);
    starGroup.add(starMesh);

    // 点光源让星星发光
    const starLight = new THREE.PointLight(0xffcc00, 2, 10);
    starGroup.add(starLight);

    // 星星光晕
    const spriteMap = new THREE.TextureLoader().load('https://raw.githubusercontent.com/mrdoob/three.js/master/examples/textures/sprites/spark1.png');
    const spriteMat = new THREE.SpriteMaterial({ map: spriteMap, color: 0xffdd00, blending: THREE.AdditiveBlending });
    const sprite = new THREE.Sprite(spriteMat);
    sprite.scale.set(7.5, 7.5, 1);
    starGroup.add(sprite);
    
    starGroup.position.y = 11;
    scene.add(starGroup);

    // 灯光
    const ambLight = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(ambLight);
    const dirLight = new THREE.DirectionalLight(0xffffff, 1);
    dirLight.position.set(5, 5, 5);
    scene.add(dirLight);

    // --- 雪花 ---
    const snowCount = 4000;
    const snowGeom = new THREE.BufferGeometry();
    const snowPos = new Float32Array(snowCount * 3);
    for (let i = 0; i < snowCount; i++) {
      snowPos[i * 3] = (Math.random() - 0.5) * 60;
      snowPos[i * 3 + 1] = Math.random() * 50 - 10;
      snowPos[i * 3 + 2] = (Math.random() - 0.5) * 60;
    }
    snowGeom.setAttribute('position', new THREE.BufferAttribute(snowPos, 3));
    const snowPoints = new THREE.Points(snowGeom, new THREE.PointsMaterial({ size: 0.08, color: 0xffffff, transparent: true, opacity: 0.5 }));
    scene.add(snowPoints);

    sceneRef.current = {
      scene, camera, renderer, treePoints, snowPoints, star: starGroup,
      originalPositions, particleCount, clock
    };

    // --- 动画循环 ---
    let smoothPalmScale = 1.0;
    let smoothPinchFocus = 1.0;

    const animate = () => {
      requestAnimationFrame(animate);
      const dt = clock.getDelta();
      const elapsed = clock.getElapsedTime();
      if (!sceneRef.current) return;

      const { treePoints, snowPoints, star, originalPositions } = sceneRef.current;
      const pos = treePoints.geometry.attributes.position.array as Float32Array;

      // 手势过渡
      smoothPalmScale += ((gestureState.isOpenPalm ? 1.5 : 1.0) - smoothPalmScale) * 0.1;
      smoothPinchFocus += ((gestureState.isPinching ? 0.12 : 1.0) - smoothPinchFocus) * 0.1;

      // 圣诞树自转
      treePoints.rotation.y += 0.25 * dt;
      const breathe = 1.0 + Math.sin(elapsed * 1.5) * 0.02;

      for(let i=0; i<particleCount; i++) {
        const ix = i * 3;
        const xO = originalPositions[ix];
        const yO = originalPositions[ix+1];
        const zO = originalPositions[ix+2];

        // 引入动态微颤 (Noise Jitter)
        const ripple = Math.sin(elapsed * 2 + yO) * 0.04;
        
        pos[ix] = (xO + ripple) * smoothPalmScale * smoothPinchFocus * breathe;
        pos[ix+1] = yO * smoothPalmScale;
        pos[ix+2] = (zO + ripple) * smoothPalmScale * smoothPinchFocus * breathe;
      }
      treePoints.geometry.attributes.position.needsUpdate = true;

      // 星星动态：自转 + 缩放闪烁
      star.rotation.y += 1.0 * dt;
      const sScale = (1.1 + Math.sin(elapsed * 8) * 0.15) * smoothPalmScale;
      star.scale.set(sScale, sScale, sScale);
      star.position.y = 11 * smoothPalmScale;

      // 雪花
      const sp = snowPoints.geometry.attributes.position.array as Float32Array;
      for(let i=0; i<snowCount; i++) {
        sp[i*3+1] -= 0.07;
        if(sp[i*3+1] < -15) sp[i*3+1] = 35;
        sp[i*3] += Math.sin(elapsed + i) * 0.005;
      }
      snowPoints.geometry.attributes.position.needsUpdate = true;

      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
      if (containerRef.current) containerRef.current.removeChild(renderer.domElement);
    };
  }, []);

  // 颜色更新
  useEffect(() => {
    if (!sceneRef.current) return;
    const { treePoints, particleCount } = sceneRef.current;
    const colors = treePoints.geometry.attributes.color.array as Float32Array;
    const palette = COLOR_PALETTES[colorMode];
    for (let i = 0; i < particleCount; i++) {
      const c = new THREE.Color(palette[i % palette.length]);
      // 随机亮度扰动，增加闪烁感
      c.multiplyScalar(0.8 + Math.random() * 0.4);
      colors[i*3] = c.r; colors[i*3+1] = c.g; colors[i*3+2] = c.b;
    }
    treePoints.geometry.attributes.color.needsUpdate = true;
  }, [colorMode]);

  return <div ref={containerRef} className="w-full h-full" />;
};

export default Scene;
