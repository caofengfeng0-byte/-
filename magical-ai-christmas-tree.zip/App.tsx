
import React, { useState, useEffect } from 'react';
import { Hand, Scissors, Sparkles, Info } from 'lucide-react';
import Scene from './components/Scene';
import HandTracker from './components/HandTracker';
import { TreeColorMode, GestureState, COLOR_PALETTES } from './types';

const App: React.FC = () => {
  const [colorMode, setColorMode] = useState<TreeColorMode>(TreeColorMode.GOLD);
  const [gestureState, setGestureState] = useState<GestureState>({
    isOpenPalm: false,
    isPinching: false,
    isVictory: false,
    handX: 0.5,
    handY: 0.5
  });
  const [cameraActive, setCameraActive] = useState(false);
  const [showHelp, setShowHelp] = useState(true);

  const nextColorMode = () => {
    const modes = Object.values(TreeColorMode);
    const currentIndex = modes.indexOf(colorMode);
    const nextIndex = (currentIndex + 1) % modes.length;
    setColorMode(modes[nextIndex]);
  };

  useEffect(() => {
    if (gestureState.isVictory) {
      const timer = setTimeout(() => nextColorMode(), 800);
      return () => clearTimeout(timer);
    }
  }, [gestureState.isVictory]);

  return (
    <div className="relative w-full h-screen bg-black overflow-hidden font-sans">
      {/* 圣诞树场景层 */}
      <Scene colorMode={colorMode} gestureState={gestureState} />

      {/* 右侧控制面板：整合摄像头、颜色和手势提示 */}
      <div className="absolute top-4 right-4 bottom-4 flex flex-col items-end justify-between gap-4 z-40 pointer-events-none">
        
        {/* 上部：摄像头预览和颜色选择 */}
        <div className="flex flex-col items-end gap-3 pointer-events-auto">
          {/* 缩小版摄像头 */}
          <div className={`w-32 h-24 rounded-2xl border border-white/20 overflow-hidden transition-all duration-700 shadow-2xl bg-black/40 backdrop-blur-md ${cameraActive ? 'opacity-100' : 'opacity-20'}`}>
            <HandTracker onStateChange={setGestureState} onActive={setCameraActive} />
          </div>

          {/* 缩小版颜色板 */}
          <div className="bg-white/5 backdrop-blur-xl p-2.5 rounded-[1.5rem] border border-white/10 shadow-xl">
            <div className="grid grid-cols-2 gap-2">
              {Object.keys(TreeColorMode).map((mode) => (
                <button
                  key={mode}
                  onClick={() => setColorMode(mode as TreeColorMode)}
                  className={`w-6 h-6 rounded-full border transition-all duration-300 ${colorMode === mode ? 'border-white scale-110 shadow-[0_0_10px_white]' : 'border-transparent opacity-40 hover:opacity-100'}`}
                  style={{ background: `linear-gradient(135deg, #${COLOR_PALETTES[mode as TreeColorMode][0].toString(16).padStart(6,'0')}, #${COLOR_PALETTES[mode as TreeColorMode][1].toString(16).padStart(6,'0')})` }}
                />
              ))}
            </div>
          </div>
        </div>

        {/* 中部：紧凑型手势提示器 (垂直排列) */}
        <div className="flex flex-col gap-3 p-2 bg-white/5 backdrop-blur-xl rounded-2xl border border-white/10 shadow-xl pointer-events-auto">
          {[
            { icon: <Hand size={18} />, label: '🖐️', active: gestureState.isOpenPalm, color: 'text-yellow-400' },
            { icon: <Scissors size={18} />, label: '✌️', active: gestureState.isVictory, color: 'text-green-400' },
            { icon: <Sparkles size={18} />, label: '🤌', active: gestureState.isPinching, color: 'text-blue-400' }
          ].map((item, idx) => (
            <div key={idx} className={`flex flex-col items-center p-2 rounded-xl transition-all duration-300 ${item.active ? 'bg-white/20 scale-110 shadow-lg' : 'opacity-30 grayscale'}`}>
              <div className={item.active ? item.color : 'text-white opacity-60'}>
                {item.icon}
              </div>
            </div>
          ))}
        </div>

        {/* 底部：帮助按钮 */}
        <button 
          onClick={() => setShowHelp(true)} 
          className="p-3 bg-white/5 hover:bg-white/10 rounded-full text-white/40 transition-all border border-white/10 pointer-events-auto"
        >
          <Info size={20} />
        </button>
      </div>

      {/* 初始帮助遮罩层 */}
      {showHelp && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-6 text-center">
          <div className="max-w-xs sm:max-w-md w-full">
            <h1 className="text-3xl sm:text-5xl font-black italic mb-6 bg-gradient-to-r from-red-500 via-white to-green-500 bg-clip-text text-transparent">CHRISTMAS TREE</h1>
            <div className="space-y-3 mb-8 text-left">
              {[
                { emoji: "🖐️", title: "五指张开", desc: "控制树的生长放大" },
                { emoji: "✌️", title: "胜利手势", desc: "动态切换粒子色系" },
                { emoji: "🤌", title: "双指捏合", desc: "聚焦核心能量粒子" }
              ].map((h, i) => (
                <div key={i} className="flex items-center gap-4 bg-white/5 p-4 rounded-2xl border border-white/10">
                  <span className="text-2xl">{h.emoji}</span>
                  <div>
                    <p className="font-bold text-white text-sm">{h.title}</p>
                    <p className="text-[10px] text-gray-400 leading-tight">{h.desc}</p>
                  </div>
                </div>
              ))}
            </div>
            <button 
              onClick={() => setShowHelp(false)} 
              className="w-full py-4 bg-white text-black rounded-full font-black text-lg hover:scale-105 transition-transform shadow-2xl"
            >
              START
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
